import os, logging
from dotenv import load_dotenv
from binance.client import Client
from binance.exceptions import BinanceAPIException

load_dotenv()
logging.basicConfig(filename='../bot.log', level=logging.INFO,
                    format='[%(asctime)s] %(levelname)s %(message)s')

client = Client(os.getenv('API_KEY'), os.getenv('API_SECRET'),
                testnet=True)
client.FUTURES_URL = 'https://testnet.binancefuture.com'

def place_limit(symbol, side, qty, price):
    try:
        resp = client.futures_create_order(symbol=symbol,
                                           side=side,
                                           type='LIMIT',
                                           timeInForce='GTC',
                                           quantity=qty,
                                           price=price)
        logging.info(f"LIMIT {side} {symbol} qty {qty} @ {price} => {resp}")
        print("Order executed:", resp)
    except BinanceAPIException as e:
        logging.error(f"Error: {e.status_code} {e.message}")
        print("Error:", e.message)
        if e.code == -4109:
            print("Inactive account: transfer assets to activate trading.")

if __name__ == '__main__':
    import sys
    if len(sys.argv) != 5:
        print("Usage: python limit_orders.py symbol SIDE qty price")
        sys.exit(1)
    _, symbol, side, qty, price = sys.argv
    if side not in ['BUY', 'SELL']:
        print("Side must be BUY or SELL")
        sys.exit(1)
    place_limit(symbol, side, float(qty), price)
