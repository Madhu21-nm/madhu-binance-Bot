import os, logging
from dotenv import load_dotenv
from binance.client import Client
from binance.exceptions import BinanceAPIException
load_dotenv()

client = Client(os.getenv("API_KEY"), os.getenv("API_SECRET"), testnet=True)
logging.basicConfig(filename="bot.log", level=logging.INFO, format="%(message)s")

def twap(symbol, side, quantity, duration, limitPrice=None):
    payload = {"symbol": symbol, "side": side, "quantity": quantity, "duration": duration}
    if limitPrice is not None:
        payload["limitPrice"] = str(limitPrice)
    try:
        resp = client._request("POST", "/sapi/v1/algo/futures/newOrderTwap", payload)
        logging.info({"event": "twap_submit", **payload, "response": resp})
        return resp
    except BinanceAPIException as e:
        logging.error({"event": "error_twap", "code": e.code, "msg": e.message})
        raise

if __name__ == "__main__":
    import argparse
    p = argparse.ArgumentParser()
    p.add_argument("--symbol", required=True)
    p.add_argument("--side", choices=["BUY", "SELL"], required=True)
    p.add_argument("--quantity", type=float, required=True)
    p.add_argument("--duration", type=int, required=True)
    p.add_argument("--limitPrice", type=float)
    args = p.parse_args()
    twap(args.symbol, args.side, args.quantity, args.duration, args.limitPrice)
