import os, logging
from binance.client import Client
from dotenv import load_dotenv
from binance.exceptions import BinanceAPIException
load_dotenv()

client = Client(os.getenv("API_KEY"), os.getenv("API_SECRET"), testnet=True)
logging.basicConfig(filename="bot.log", level=logging.INFO, format="%(message)s")

def oco(symbol, side, quantity, tp_price, sl_price):
    try:
        main = client.futures_create_order(symbol=symbol, side=side,
                                           type="MARKET", quantity=quantity)
        logging.info({"event": "oco_main", "symbol": symbol, "side": side,
                      "qty": quantity, "response": main})
        opp = "SELL" if side == "BUY" else "BUY"
        tp = client.futures_create_order(symbol=symbol, side=opp,
            type="TAKE_PROFIT_MARKET", stopPrice=str(tp_price),
            quantity=quantity, reduceOnly=True)
        sl = client.futures_create_order(symbol=symbol, side=opp,
            type="STOP_MARKET", stopPrice=str(sl_price),
            quantity=quantity, reduceOnly=True)
        logging.info({"event": "oco_tp", "response": tp})
        logging.info({"event": "oco_sl", "response": sl})
        return {"main": main, "tp": tp, "sl": sl}
    except BinanceAPIException as e:
        logging.error({"event": "error_oco", "code": e.code, "msg": e.message})
        raise

if __name__ == "__main__":
    import argparse
    p = argparse.ArgumentParser()
    p.add_argument("--symbol", required=True)
    p.add_argument("--side", choices=["BUY", "SELL"], required=True)
    p.add_argument("--quantity", type=float, required=True)
    p.add_argument("--tp_price", type=float, required=True)
    p.add_argument("--sl_price", type=float, required=True)
    args = p.parse_args()
    oco(args.symbol, args.side, args.quantity, args.tp_price, args.sl_price)
