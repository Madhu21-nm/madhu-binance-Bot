import os, sys
import logging
from binance.um_futures import UMFutures
from binance.error import ClientError

API_KEY = 'your_testnet_api_key'
API_SECRET = 'your_testnet_secret'
BASE_URL = 'https://testnet.binancefuture.com'

if not API_KEY or not API_SECRET:
    print("Missing API credentials.")
    sys.exit(1)

logging.basicConfig(
    filename='bot.log',
    level=logging.INFO,
    format='[%(asctime)s] %(levelname)s %(message)s'
)

client = UMFutures(key=API_KEY, secret=API_SECRET, base_url=BASE_URL)

def place_market(symbol: str, side: str, qty: float):
    try:
        resp = client.new_order(symbol=symbol, side=side,
                                type="MARKET", quantity=qty)
        logging.info(f"MARKET {side} {symbol} qty {qty} => {resp}")
        print("Order executed:", resp)
    except ClientError as e:
        logging.error(f"Error: {e.status_code} {e.error_code} {e.error_message}")
        print("Error:", e.error_message)
        if getattr(e, 'error_code', None) == -4109:
            print("Account inactive. Transfer assets to enable trading.")

if __name__ == "__main__":
    if len(sys.argv) != 4:
        print("Usage: python market_orders.py SYMBOL SIDE BUY/SELL QTY")
        sys.exit(1)

    _, symbol, side, qty_str = sys.argv
    side = side.upper()
    if side not in ['BUY', 'SELL']:
        print("Side must be BUY or SELL")
        sys.exit(1)

    try:
        qty = float(qty_str)
    except ValueError:
        print("Quantity must be numeric")
        sys.exit(1)

    place_market(symbol.upper(), side, qty)
