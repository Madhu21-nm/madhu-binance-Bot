import os, logging
from dotenv import load_dotenv
from binance.client import Client
from binance.exceptions import BinanceAPIException

load_dotenv()
logging.basicConfig(filename='../../bot.log', level=logging.INFO,
                    format='[%(asctime)s] %(levelname)s %(message)s')

client = Client(os.getenv('API_KEY'), os.getenv('API_SECRET'),
                testnet=True)
client.FUTURES_URL = 'https://testnet.binancefuture.com'

def place_stop_limit(symbol, side, qty, stop_price, limit_price):
    try:
        resp = client.futures_create_order(symbol=symbol,
                                           side=side,
                                           type='STOP_LOSS_LIMIT',
                                           timeInForce='GTC',
                                           quantity=qty,
                                           stopPrice=stop_price,
                                           price=limit_price,
                                           workingType='CONTRACT_PRICE')
        logging.info(f"STOP_LIMIT {side} {symbol} qty {qty}, stop {stop_price}, limit {limit_price} => {resp}")
        print("Stop-limit order sent:", resp)
    except BinanceAPIException as e:
        logging.error(f"Error: {e.code} {e.message}")
        print("Error:", e.message)
        if e.code == -4109:
            print("Inactive account: transfer assets to activate futures account.")

if __name__ == '__main__':
    import sys
    if len(sys.argv) != 6:
        print("Usage: python stop_limit.py symbol SIDE qty stopPrice limitPrice")
        sys.exit(1)
    _, symbol, side, qty, sp, lp = sys.argv
    if side not in ['BUY', 'SELL']:
        print("Side must be BUY or SELL")
        sys.exit(1)
    place_stop_limit(symbol, side, float(qty), sp, lp)
